<?php
$marchand = array(
    "apikey" => "", // Enrer votre apikey
    "site_id" => "", //Entrer votre site_ID
    "secret_key" => "" //Entrer votre clé secret
);